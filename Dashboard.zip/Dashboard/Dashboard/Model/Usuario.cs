﻿using System;
namespace Dashboard.Model
{
	public class Usuario
	{
		public Usuario()
		{
		}
	}
}

