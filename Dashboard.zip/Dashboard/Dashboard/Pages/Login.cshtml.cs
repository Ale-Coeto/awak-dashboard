using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Dashboard;
using Microsoft.AspNetCore.Http;

//using namespace Dashboar;

namespace Dashboard.Pages
{
    public class LoginModel : PageModel
    {
        [BindProperty]
        [Required(ErrorMessage = "El campo \'Correo\' es obligatorio.")]
        [EmailAddress(ErrorMessage = "El formato del correo electrónico no es válido.")]
        public string Correo { get; set; } = "";

        [BindProperty]
        [Required(ErrorMessage = "El campo 'Contraseña' es obligatorio.")]
        public string Contrasenia { get; set; } = "";
        
        public Usuario ValidUser { get; set; }



        public IActionResult OnPost()
        {
            

            if (!ModelState.IsValid)
            {
                return Page();
            }

            ValidUser = DatabaseManager.IsValidUser(Correo, Contrasenia);

            if (ValidUser != -1)
            {
                HttpContext.Session.SetString("ID", ValidUser.ToString());
                HttpContext.Session.SetString("Correo", Correo);
                return RedirectToPage("./Inicio");
            }
            else
                return Page();
        }
    }
}